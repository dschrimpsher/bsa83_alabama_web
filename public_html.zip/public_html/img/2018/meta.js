var items = [
  {
    "src": "./img/2018/temple-2-2018.jpg",
    "w": 1024,
    "h": 768,
    "title": "Temple B'nai Sholom"
  },
  {
    "src": "./img/2018/temple-4-2018.jpg",
    "w": 768,
    "h": 1024,
    "title": "Temple B'nai Sholom"
  },
  {
    "src": "./img/2018/temple-3-2018.jpg",
    "w": 1024,
    "h": 768,
    "title": "Temple B'nai Sholom"
  },
  {
    "src": "./img/2018/temple-1-2018.jpg",
    "w": 768,
    "h": 1024,
    "title": "Temple B'nai Sholom"
  },
  {
    "src": "./img/2018/lost_sea_campsite.jpg",
    "w": 1024,
    "h": 768,
    "title": "Lost Sea Cave: Camping in a Cave"
  },
  {
    "src": "./img/2018/lost_sea_eye_of_the_needle.jpg",
    "w": 1024,
    "h": 768,
    "title": "Lost Sea Cave: Eye of the Needle"
  }
];
